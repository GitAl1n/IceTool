<?php
$client_id = "";
$client_secret = "";
$test_username = "";
$test_password = "";
?>
