<?php

namespace Netatmo\Common;

class NACameraImageInfo
{
    const CII_ID = "id";
    const CII_VERSION = "version";
    const CII_KEY = "key";
}

?>
