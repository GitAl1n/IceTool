<?php

namespace Netatmo\Common;

class NARadioRssiTreshold
{
    const RADIO_THRESHOLD_0 = 90;/*low signal*/
    const RADIO_THRESHOLD_1 = 80;/*signal medium*/
    const RADIO_THRESHOLD_2 = 70;/*signal high*/
    const RADIO_THRESHOLD_3 = 60;/*full signal*/
}


?>
